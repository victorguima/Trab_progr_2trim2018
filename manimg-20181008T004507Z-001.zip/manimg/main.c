#include<conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <string.h>

int abrearq(int flag){
    //Cria as structs de dados
    typedef struct{
        short formarq; //Guarda o formato do arquivo
        int peso; //Guarda o peso do arquivo
        short int reserved;
        short int reserved2;
        int deslocamento; //tamanho do cabe�alho
    } cabecaarq;


    typedef struct{
        int tamancabeca; //Tamanho do cabe�alho
        int height; //Altura
        int widht; //Largura
        short int quantiplanos; //Quantidade de planos
        short int profundidade; //Profundidade de cores
        int compressao; //Compressao do arquivo
        int pesoimg; //Peso da imagem
        int pixpmh; //Pixels por metro. Horizontal
        int pixpmv; //Pixels por metro. Vertical
        int qcolor; //Quantidade de cores;
        int colorimp; //Cores importantes
    } cabecaimg;

    cabecaarq arquivo;
    cabecaimg img;
    FILE *open;
    system("cls"); //Limpa tela
    char nome[10];
    printf("Digite o nome do arquivo: \nO arquivo deve estar na pasta do execut�vel do programa.\n");
    scanf("%s",nome); //espera a entrada do usuario para nome do arquivo
    strcat(nome,".bmp"); //Adiciona a extens�o do arquivo .bmp
    open=fopen(nome,"rb"); //abre a imagem
    if(open == NULL){ //Testa se foi poss�vel abrir o arquivo
        printf("\n�h meu Deus, n�o pude abrir o arquivo.");
        main();
    }
    fread(&arquivo.formarq,sizeof(arquivo.formarq),1,open);
    if(arquivo.formarq==0x4d42){ //Se o arquivo for bmp o programa l� os dados
        printf("Formato do Arquivo: BMP\n");
        fread(&arquivo.peso, sizeof(arquivo.peso), 1, open);
        printf("O arquivo pesa: %i bytes",arquivo.peso);
        fread(&arquivo.reserved, sizeof(arquivo.reserved),1,open);
        fread(&arquivo.reserved2,sizeof(arquivo.reserved2),1,open);
        fread(&arquivo.deslocamento,sizeof(arquivo.deslocamento),1,open);
        printf("\nO deslocamento � de: %d",arquivo.deslocamento);
        fread(&img.tamancabeca,sizeof(img.tamancabeca),1,open);
        fread(&img.height,sizeof(img.height),1,open);
        fread(&img.widht,sizeof(img.widht),1,open);
        printf("\nA imagem tem tamanho: %dx%d",img.height,img.widht);
        fread(&img.quantiplanos,sizeof(img.quantiplanos),1,open);
        fread(&img.profundidade,sizeof(img.profundidade),1,open);
        printf("\nA imagem tem uma profundidade de cores de: %dbits",img.profundidade);
        fread(&img.compressao,sizeof(img.compressao),1,open);
        fread(&img.pesoimg,sizeof(img.pesoimg),1,open);
        printf("\nA imagem pesa: %d\n",img.pesoimg);
        fread(&img.pixpmh,sizeof(img.pixpmh),1,open);
        fread(&img.pixpmv,sizeof(img.pixpmv),1,open);
        fread(&img.qcolor,sizeof(img.qcolor),1,open);
        fread(&img.colorimp,sizeof(img.colorimp),1,open);

        unsigned char *enderecomapa;
        enderecomapa=malloc(img.pesoimg); //Alocando espa�o na mem�ria
        fread(enderecomapa,img.pesoimg,1,open); //Enviando a imagem para mem�ria
        fclose(open);

        open=fopen("copiaimg.bmp","wb");
        //escreve os dados na c�pia para manipula��o
        fwrite(&arquivo.formarq, sizeof(arquivo.formarq),1,open);
        fwrite(&arquivo.peso,sizeof(arquivo.peso),1,open);
        fwrite(&arquivo.reserved,sizeof(arquivo.reserved),1,open);
        fwrite(&arquivo.reserved2,sizeof(arquivo.reserved2),1,open);
        fwrite(&arquivo.deslocamento,sizeof(arquivo.deslocamento),1,open);
        fwrite(&img.tamancabeca,sizeof(img.tamancabeca),1,open);
        fwrite(&img.height,sizeof(img.height),1,open);
        fwrite(&img.widht,sizeof(img.widht),1,open);
        fwrite(&img.quantiplanos,sizeof(img.quantiplanos),1,open);
        fwrite(&img.profundidade,sizeof(img.profundidade),1,open);
        fwrite(&img.compressao,sizeof(img.compressao),1,open);
        fwrite(&img.pesoimg,sizeof(img.pesoimg),1,open);
        fwrite(&img.pixpmh,sizeof(img.pixpmh),1,open);
        fwrite(&img.pixpmv,sizeof(img.pixpmv),1,open);
        fwrite(&img.qcolor,sizeof(img.qcolor),1,open);
        fwrite(&img.colorimp,sizeof(img.colorimp),1,open);
        fwrite(enderecomapa,img.pesoimg,1,open);
        fclose(open);
        system("pause");
        system("cls");
        return(img.pesoimg); //retorna 1 para a flagprograma da fun��o menu.
    }
}

int gravacor(){
    //Escreve Vermelho
    FILE *open;
    open=fopen("copiaimg.bmp","rb");
    int *cabeca1, *tamanho, *cabeca2;
    cabeca1=malloc(34); //Armazena mem�ria
    tamanho=malloc(4);
    cabeca2=malloc(16);
    fread(cabeca1,34,1,open); //Le primeira parte do cabecalho
    fread(tamanho,4,1,open); //le tamanho
    fread(cabeca2,16,1,open);
    printf("\nA imagem vermelha foi gerada!\n ",*tamanho);
    unsigned char *mapa;
    mapa=malloc(*tamanho);
    fread(mapa,*tamanho,1,open); //Le mapa de bits
    fclose(open); //fecha arquivo
    open=fopen("img_R.bmp","wb"); //abre c�pia
    fwrite(cabeca1,34,1,open);
    fwrite(tamanho,4,1,open);
    fwrite(cabeca2,16,1,open);
    int ctrl=0;
    int i=0;
    unsigned char cor[3];
    while(ctrl<*tamanho){
        for(i=0;i<3;i++){
            cor[i]=*mapa; //coloca o valor do conjunto para o vetor
            mapa++;
            ctrl++; //Pula para o pr�ximo byte
        }
        if((cor[0]) && (!(cor[1])) && (!(cor[2]))){//detecta azul
            mapa=mapa-3;
            for(i=0;i<3;i++){
                *mapa=0xFF;
                mapa++;
            }
        }
        if(!(cor[0]) && ((cor[1])) && (!(cor[2]))){ //detecta verde
            mapa=mapa-3;
            for(i=0;i<3;i++){
                *mapa=0xFF;
                mapa++;
            }
        }

    }
    mapa=mapa-*tamanho;
    fwrite(mapa,*tamanho,1,open); //escreve mapa de bits
    fclose(open);
    //Escreveu o valor vermelho;

    //Escreve verde
    open=fopen("copiaimg.bmp","rb");
    fread(cabeca1,34,1,open);
    fread(tamanho,4,1,open);
    fread(cabeca2,16,1,open);
    printf("A imagem verde foi gerada!\n ",*tamanho);
    fread(mapa,*tamanho,1,open);
    fclose(open);
    //char nomev[15];
    //strcpy(nome,nomev);
    //strcat(nomev,"_V.bmp");
    //open=fopen(nomev,"wb");
    open=fopen("img_V.bmp","wb");
    fwrite(cabeca1,34,1,open);
    fwrite(tamanho,4,1,open);
    fwrite(cabeca2,16,1,open);
    ctrl=0;
    while(ctrl<*tamanho){
        for(i=0;i<3;i++){
            cor[i]=*mapa; //coloca o valor do conjunto para o vetor
            mapa++;
            ctrl++; //Pula para o pr�ximo byte
        }
        if(!(cor[0]) && (!(cor[1])) && ((cor[2]))){//detecta vermelho
            mapa=mapa-3;
            for(i=0;i<3;i++){
                *mapa=0xFF;
                mapa++;
            }
        }
        if((cor[0]) && (!(cor[1])) && (!(cor[2]))){ //detecta azul
            mapa=mapa-3;
            for(i=0;i<3;i++){
                *mapa=0xFF;
                mapa++;
            }
        }
    }
    mapa=mapa-*tamanho;
    fwrite(mapa,*tamanho,1,open);
    fclose(open);
    //escreveu o valor verde

    //Escreve Azul
    open=fopen("copiaimg.bmp","rb");
    fread(cabeca1,34,1,open);
    fread(tamanho,4,1,open);
    fread(cabeca2,16,1,open);
    printf("A imagem azul foi gerada!\n ",*tamanho);
    fread(mapa,*tamanho,1,open);
    fclose(open);
    //strcat(nome,"_B.bmp");
    //open=fopen(nome,"wb");
    open=fopen("img_B.bmp","wb");
    fwrite(cabeca1,34,1,open);
    fwrite(tamanho,4,1,open);
    fwrite(cabeca2,16,1,open);
    ctrl=0;
    while(ctrl<*tamanho){
        for(i=0;i<3;i++){
            cor[i]=*mapa; //coloca o valor do conjunto para o vetor
            mapa++;
            ctrl++; //Pula para o pr�ximo byte
        }
        if(!(cor[0]) && (!(cor[1])) && ((cor[2]))){//detecta vermelho
            mapa=mapa-3;
            for(i=0;i<3;i++){
                *mapa=0xFF;
                mapa++;
            }
        }
        if(!(cor[0]) && ((cor[1])) && (!(cor[2]))){ //detecta verde
            mapa=mapa-3;
            for(i=0;i<3;i++){
                *mapa=0xFF;
                mapa++;
            }
        }
    }
    mapa=mapa-*tamanho;
    fwrite(mapa,*tamanho,1,open);
    fclose(open);
    system("pause");
    system("cls");
}

void grayscale(){
    FILE *open;
    open=fopen("copiaimg.bmp","rb"); //abre c�pia
    int *cabeca1, *tamanho, *cabeca2;
    cabeca1=malloc(34); //aloca memoria
    tamanho=malloc(4);
    cabeca2=malloc(16);
    fread(cabeca1,34,1,open); //le dados
    fread(tamanho,4,1,open);
    fread(cabeca2,16,1,open);
    unsigned char *mapa;
    mapa=malloc(*tamanho); //aloca memoria mapa
    unsigned char *gs;
    gs=malloc(*tamanho); //aloca memoria grayscale
    fread(mapa,*tamanho,1,open); //le mapa de bits
    fclose(open);
    int ctrl=0, i;
    unsigned char cor[3];
    while(ctrl<*tamanho){
        for(i=0;i<3;i++){
            cor[i]=*mapa;
            mapa++;
            ctrl++;
        }

        for(i=0;i<3;i++){ //
            *gs=((cor[0]*0.3)+(cor[1]*0.59)+(cor[2]*0.11)); //define a quantidade de cada cor
            gs++; //avanca bit
        }
    }
    gs=gs-*tamanho; //posiciona no inicio do endere�o
    open=fopen("img_gs.bmp","wb");
    fwrite(cabeca1,34,1,open); //escreve arquivo
    fwrite(tamanho,4,1,open);
    fwrite(cabeca2,16,1,open);
    fwrite(gs,*tamanho,1,open);
    fclose(open);


    //Liberando espa�o de mem�ria
    free(mapa);
    free(gs);
    free(cabeca1);
    free(tamanho);
    free(cabeca2);

    //Exibe confirma��o na tela
    printf("\nImagem gerada com �xito com o nome de img_gs.bmp!\n");
    system("pause");
    system("cls");
}

void selecor()
{

    puts("Escolha a cor que deseja destacar:");
    puts("1. Azul");
    puts("2. Verde");
    puts("3. Vermelho");
    int corEscolhida = (getch()-'0');
    int larguraMax = 0, alturaMax = 0, larguraMin = 819, alturaMin = 460;
    int alturaCtrl, larguraCtrl;
    FILE *fp;
    fp=fopen("copiaimg.bmp","rb");
    int *tamanho, *largura, *altura, *cabecalho;
    cabecalho=malloc(54);
    fread(cabecalho,54,1,fp);
    tamanho=malloc(4);
    largura=malloc(4);
    altura=malloc(4);
    fseek(fp,18,SEEK_SET);
    fread(largura,4,1,fp);
    fread(altura,4,1,fp);
    fseek(fp,34,SEEK_SET);
    fread(tamanho,4,1,fp);
    unsigned char * ponteiroalloc = (unsigned char *) malloc (*tamanho);
    fseek(fp, 54, SEEK_SET); // Coloca o indicador logo depois do cabe�alho
    fread(ponteiroalloc, *tamanho, 1, fp);
    fclose(fp);
    int ctrl = 0;
    int i=0;
    int cor[3];
    unsigned char * temp = ponteiroalloc;

    for (alturaCtrl = 0; alturaCtrl < *altura; alturaCtrl++)
    {
        for (larguraCtrl = 0; larguraCtrl < (*largura)+1; larguraCtrl++)
        {
            for (i = 0; i<3; i++)
            {
                cor[i] = *(ponteiroalloc+ctrl); // Analisa os 3 bits de cor
                ctrl++;
            }

            /* A partir daqui, cada vez que a cor desejada for encontrada,
            se  testa e estabelece os 4 cantos do retangulo */

            switch(corEscolhida)
            {
            case 1:
                {
                    if ((cor[0]) && (!(cor[1])) && (!(cor[2]))) // Caso for azul
                    {
                        if (larguraCtrl > larguraMax) larguraMax = larguraCtrl;
                        if (larguraCtrl < larguraMin) larguraMin = larguraCtrl;
                        if (alturaCtrl > alturaMax) alturaMax = alturaCtrl;
                        if (alturaCtrl < alturaMin) alturaMin = alturaCtrl;

                    }


                    break;
                }
            case 2:
                {
                    if ((!(cor[0])) && cor[1] && (!(cor[2]))) // Caso for verde
                    {
                        if (larguraCtrl > larguraMax) larguraMax = larguraCtrl;
                        if (larguraCtrl < larguraMin) larguraMin = larguraCtrl;
                        if (alturaCtrl > alturaMax) alturaMax = alturaCtrl;
                        if (alturaCtrl < alturaMin) alturaMin = alturaCtrl;



                    }
                    break;
                }
            case 3:
                if((!(cor[0])) && (!(cor[1])) && cor[2]) // Caso for vermelho
                {
                        if (larguraCtrl > larguraMax) larguraMax = larguraCtrl;
                        if (larguraCtrl < larguraMin) larguraMin = larguraCtrl;
                        if (alturaCtrl > alturaMax) alturaMax = alturaCtrl;
                        if (alturaCtrl < alturaMin) alturaMin = alturaCtrl;
                }
                break;

            }
        }

    }

    ponteiroalloc = temp; // Volta o ponteiro para o come�o



    for (alturaCtrl = 0; alturaCtrl < (*altura); alturaCtrl++)
    {
        for (larguraCtrl = 0; larguraCtrl < (*largura)+1; larguraCtrl++)
        {
            ponteiroalloc += 3; // Avan�a 3 bytes cada vez

            /* Caso o valor esteja na altura certa e entre a largura minima e maxima */
            if (((alturaCtrl == alturaMin) || (alturaCtrl == alturaMax)))
                if ((larguraCtrl+1 >= larguraMin) && (larguraCtrl <= larguraMax))
                {
                    for (i = 0; i < 3; i++) // Zera os 3 bytes, deixando o pixel preto
                    {
                        *(ponteiroalloc) = 0; // Zera o valor no byte
                        ponteiroalloc++;  // Avan�a um byte
                    }
                    ponteiroalloc -= 3; // Volta os 3 bytes para n�o skippar os proximos 3

                }

            /* Caso o valor esteja na largura certa e entre a altura minima e maxima */

            if (((larguraCtrl+1 == larguraMin) || (larguraCtrl == larguraMax)))
                if ((alturaCtrl >= alturaMin) && (alturaCtrl <= alturaMax))
                {
                    for (i = 0; i < 3; i++){
                        *(ponteiroalloc) = 0;
                        ponteiroalloc++;
                    }
                    ponteiroalloc -= 3;
                }
        }

    }

        fp = fopen("img_achei.bmp", "wb");
        fwrite(cabecalho, 54, 1, fp);
        fwrite(temp, *tamanho, 1, fp);
        fclose(fp);
}

void menu (void){
    printf("\n BEM VINDO AO MENU DO TRABALHO\n\n");
    printf(" -> ESCOLHA UMA DENTRE AS OPCOES ABAIXO:\n\n");
    printf(" 1 - ABRIR IMAGEM \n 2 - GRAVAR CORES \n 3 - IDENTIFICAR CORES \n 4 - CRIAR ESCALAS DE CINZA\n 5 - SAIR DO PROGRAMA\n ");
    int tecla, flagprograma;
    while(1){ //Espera entrada do teclado
        if(kbhit()){
            tecla=getch();
            switch(tecla){
                case 49:
                    abrearq(0);
                    menu();
                case 50:
                    gravacor();
                    menu();
                case 51:
                    selecor();
                    menu();
                case 52:
                    grayscale();
                    menu();
                case 53:
                    printf("\nThat's all folks!");
                    remove("copiaimg.bmp");
                    exit(1);
            }
        }
    }
}

int main(){
    setlocale(LC_ALL,"Portuguese"); //Define linguagem;
    printf("Ol�! Primeira vez por aqui?!\nVoc� precisa come�ar selecionando um arquivo.\n\n");
    system("pause");
    abrearq(0);
    menu();
    return 0;
}


